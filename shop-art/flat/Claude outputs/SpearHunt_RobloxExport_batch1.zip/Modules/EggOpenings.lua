--!nonstrict
-- EggOpenings: открытия яиц SpearHunt, перенесённые из веб-прототипа формула в формулу.
-- Сгенерировано автоматически из кода прототипа. Не править вручную.
--
-- EggOpenings[eggId] = { prep, open, clear, emerge, update(t, set [, hd]), idle(t, set), events = {...}, groups = {...} }
--   set(имяГруппы, CFrame, k): CFrame — для Motor6D "<имяГруппы>_Joint".Transform; k — масштаб группы из прототипа
local EggOpenings = {}

-- ===== общая математика прототипа (совпадает с core.js) =====
local PI, TAU = math.pi, math.pi * 2
local sin, cos, abs, max, min, sqrt = math.sin, math.cos, math.abs, math.max, math.min, math.sqrt
local SCALE = 1.5 -- 1 единица прототипа = 1.5 стада

local function truthy(v) return v ~= nil and v ~= false and v ~= 0 and v ~= "" end
local function orv(a, b) if truthy(a) then return a end return b end
local function iff(c, a, b) if c then return a end return b end
local function forEach(arr, f) for i = 1, #arr do f(arr[i], i - 1) end end
local function map(arr, f) local r = {} for i = 1, #arr do r[i] = f(arr[i], i - 1) end return r end
local function round(x) return math.floor(x + 0.5) end
local function sign(x) if x > 0 then return 1 elseif x < 0 then return -1 end return 0 end
local function hypot(x, y) return sqrt(x * x + y * y) end
local function clamp(x, a, b) a = a or 0 b = b or 1 if x < a then return a elseif x > b then return b end return x end
local function lerp(a, b, t) return a + (b - a) * t end
local function ss(a, b, x) x = clamp((x - a) / (b - a)) return x * x * (3 - 2 * x) end
-- kf(u, u0,v0, u1,v1, ...) — сглаженные ключи
local function kf(u, ...)
	local k = { ... }
	if u <= k[1] then return k[2] end
	for i = 3, #k, 2 do
		if u <= k[i] then
			local d = k[i] - k[i - 2]
			if d == 0 then d = 1e-6 end
			local t = (u - k[i - 2]) / d
			return lerp(k[i - 1], k[i + 1], t * t * (3 - 2 * t))
		end
	end
	return k[#k]
end
local function wave(t, f, ph) return sin(TAU * (t * f + (ph or 0))) end
local function pulse(t, period, dur, off)
	local x = (t + (off or 0)) % period
	if x < dur then return sin(PI * x / dur) end
	return 0
end
local function bump(u, a, b) if u <= a or u >= b then return 0 end return sin(PI * (u - a) / (b - a)) end
local function outBack(t) t = clamp(t) local c = 1.70158 return 1 + (c + 1) * (t - 1) ^ 3 + c * (t - 1) ^ 2 end

-- ===== состояние яйца: те же вызовы mv / hinge / rot / sc, что в прототипе =====
-- info.groups[name] = { ax, ay, az } — ось петли группы в осях прототипа
local function register(id, info, self)
	local names, groups = info.order, info.groups
	local st = {}
	for _, n in ipairs(names) do st[n] = { d = { 0, 0, 0 }, k = 1 } end
	local e = { x = info.x, L = 0, Lc = { set = function() end } }
	e.x.gm = { material = { opacity = 0 } }
	function e.mv(n, x, y, z) local s = st[n] if s then s.d[1], s.d[2], s.d[3] = x, y, z end end
	function e.hinge(n, a, ax)
		local s = st[n] if not s then return end
		local g = groups[n]
		local vx, vy, vz = g[1], g[2], g[3]
		if ax then vx, vy, vz = ax.x, ax.y, ax.z end
		s.rot = CFrame.fromAxisAngle(Vector3.new(-vx, vy, -vz), a)
	end
	function e.rot(n, x, y, z) local s = st[n] if s then s.rot = CFrame.fromEulerAnglesXYZ(-x, y, -z) end end
	-- МАСШТАБ группы: Motor6D его не умеет, поэтому k уходит третьим аргументом в set(name, cf, k).
	function e.sc(n, s1) local s = st[n] if s then s.k = max(0.0001, s1) end end
	function e.ev() return false end -- события вынесены в таблицу events
	local fx = { emit = function() end, burst = function() end, ring = function() end, bolt = function() end, rnd = function() return 1 end }
	self.prep, self.open, self.clear, self.emerge, self.glow = info.prep, info.open, info.clear, info.emerge, info.glow

	local function reset()
		for _, s in pairs(st) do s.d[1], s.d[2], s.d[3] = 0, 0, 0 s.rot = nil s.k = 1 end
		e.L = 0
	end
	local function flush(set)
		for i = 1, #names do
			local n = names[i]
			local s = st[n]
			local cf = CFrame.new(-s.d[1] * SCALE, s.d[2] * SCALE, -s.d[3] * SCALE)
			if s.rot then cf = cf * s.rot end
			set(n, cf, s.k)
		end
		return e.L, e.x.gm.material.opacity
	end
	local entry = { id = id, name = info.name, price = info.price, pets = info.pets, groups = names,
		prep = info.prep, open = info.open, clear = info.clear, emerge = info.emerge,
		glowColor = info.glowColor, themeColor = info.themeColor, events = info.events }
	-- update(t, set [, hd]): t — секунды от начала открытия; hd — длительность появления питомца (сек).
	-- set(имяГруппы, CFrame для Motor6D.Transform, k) — k это масштаб группы из прототипа (1 = норма, →0 = исчезла).
	-- Возвращает: яркость внутреннего света (0..3) и непрозрачность свечения (0..1).
	function entry.update(t, set, hd)
		hd = hd or 2.8
		local tC = info.prep + info.open * info.emerge + hd * 0.42
		reset()
		self.seq(e, t, t - tC, fx, 0)
		return flush(set)
	end
	-- покой на витрине (как в магазине прототипа)
	function entry.idle(t, set)
		reset()
		self.seq(e, 0, -1, fx, 0)
		self.idle(e, t)
		return flush(set)
	end
	-- момент появления питомца и полная длительность
	function entry.emergeTime() return info.prep + info.open * info.emerge end
	function entry.duration(hd) hd = hd or 2.8 return info.prep + info.open * info.emerge + hd * 0.42 + info.clear end
	EggOpenings[id] = entry
end


-- ============ forest — Ð›ÐµÑÐ½Ð¾Ð¹ Ñ‚Ð°Ð»Ð¸ÑÐ¼Ð°Ð½ ============
do
local self = {}
self.seq = function(e, t, c, fx, x0)
local P = self.prep
local O = self.open
local o = (t - P)
local alive = (ss(0.1, 0.8, t) * (1 - ss((P + 0.2), (P + 0.9), t)))
for k = 0, (5) - 1 do
e.hinge(("lf" .. k), (0.05 + (alive * (0.22 + (0.2 * sin(((t * 8.5) + (k * 1.7))))))))
end
local gr = ss(0.4, 1.9, t)
e.sc("sprout", (1 + (0.55 * gr)))
e.hinge("spA", (((-0.35) * gr) + ((0.12 * alive) * sin((t * 6)))))
e.hinge("spB", ((0.35 * gr) - ((0.12 * alive) * sin(((t * 6) + 1)))))
local gl = (ss(0.8, P, t) * (1 - ss(0, 0.9, c)))
e.sc("glow", max(0.01, ((0.55 + (0.42 * gl)) + (0.03 * sin((t * 7))))))
e.x.gm.material.opacity = (0.85 * gl)
e.L = ((1.6 * gl) + (1.4 * bump(o, 0, 0.8)))
e.Lc.set(self.glow)
if (((t < P) and (t > 0.5)) and (fx.rnd() < (0.25 * alive))) then
local a = (fx.rnd() * TAU)
fx.emit({tex = "dot", p = {(x0 + (sin(a) * 1.0)), (0.6 + (fx.rnd() * 1.4)), (cos(a) * 1.0)}, v = {0, 0.35, 0}, life = 1.3, s = 0.07, s1 = 0.02, col = "#e9ff9a", sway = 0.4})
end
for k = 0, (8) - 1 do
local u = ss((1.55 + (k * 0.1)), (2.05 + (k * 0.1)), t)
local n = e.x[("bn" .. k)]
e.mv(("belt" .. k), ((n.x * 0.55) * u), ((((-1.0) * u) * u) + (0.25 * sin((u * PI)))), ((n.z * 0.55) * u))
e.hinge(("belt" .. k), (2.2 * u))
e.sc(("belt" .. k), (1 - ss(0.75, 1, u)))
if truthy(e.ev(("b" .. k), t, (1.55 + (k * 0.1)))) then
fx.burst(3, function(i, r)
return {tex = "chip", p = {(x0 + (n.x * 1.1)), 1.05, (n.z * 1.1)}, v = {((n.x * 1.2) + (r() - 0.5)), (1.2 + r()), ((n.z * 1.2) + (r() - 0.5))}, g = 5, life = 0.7, s = 0.08, col = "#b9773f", add = false, spin = 6}
end)
end
end
local tr = (ss(1.6, P, t) * (1 - ss(0, 0.3, o)))
e.mv("cap", 0, kf(o, 0, 0, 0.25, 0.25, 1.1, 1.9), 0)
e.rot("cap", 0, (max(0, o) * 3.2), (0.2 * bump(o, 0.1, 1.2)))
e.sc("cap", (1 - ss(0.7, 1.3, o)))
for k = 0, (5) - 1 do
local u = (((o - 0.12) - (k * 0.07)) / 0.95)
local a = (((0.05 * tr) * (1 + sin(((t * 30) + k)))) + iff((u > 0), (1.35 * outBack(min(1, u))), 0))
local w = ss(0, 1, (c - (k * 0.05)))
e.hinge(("pet" .. k), (a + (0.5 * w)))
e.sc(("pet" .. k), (1 - ss(0.2, 1, (c - (k * 0.05)))))
end
if truthy(e.ev("open", t, (P + 0.15))) then
fx.ring({x0, 0.08, 0}, "#c9ff8a", 0.6, 2.6, 0.9, 0.7)
fx.burst(22, function(i, r)
local a = (r() * TAU)
local s = (1.2 + (r() * 1.8))
return {tex = "leaf", p = {(x0 + (sin(a) * 0.6)), (1.5 + (r() * 0.5)), (cos(a) * 0.6)}, v = {(sin(a) * s), (1.6 + (r() * 2)), (cos(a) * s)}, g = 2.6, drag = 0.8, life = (1.6 + r()), s = (0.2 + (r() * 0.14)), col = iff((r() > 0.5), "#8fd82e", "#3fa53c"), add = false, rot = (r() * 6), spin = ((r() - 0.5) * 8), sway = 0.6}
end)
fx.burst(26, function(i, r)
local a = (r() * TAU)
return {tex = "dot", p = {(x0 + ((sin(a) * 0.5) * r())), 1.2, ((cos(a) * 0.5) * r())}, v = {(sin(a) * 0.5), (0.8 + (r() * 1.6)), (cos(a) * 0.5)}, life = (1.4 + r()), s = 0.1, s1 = 0.02, col = "#f1ffb0", sway = 0.5, drag = 0.6}
end)
end
e.mv("cup", 0, ((-0.5) * ss(0.1, 1.2, c)), 0)
e.sc("cup", (1 - ss(0.25, 1.25, c)))
end
self.idle = function(e, t)
e.hinge("spA", (0.08 * wave(t, 0.5)))
e.hinge("spB", ((-0.08) * wave(t, 0.5, 0.2)))
for k = 0, (5) - 1 do
e.hinge(("lf" .. k), (0.03 + (0.03 * wave(t, 0.4, (k * 0.2)))))
end
e.sc("glow", 0.01)
end
register("forest", {
	name = "Ð›ÐµÑÐ½Ð¾Ð¹ Ñ‚Ð°Ð»Ð¸ÑÐ¼Ð°Ð½", price = 59, prep = 2.5, open = 1.5, clear = 1.3, emerge = 0.55, glow = "#f4ffb0",
	glowColor = Color3.fromRGB(244, 255, 176), themeColor = Color3.fromRGB(111, 208, 74),
	pets = { "clover_beetle", "moss_bunny", "hazel_squirrel", "flower_hedgehog", "guardian_fawn" },
	order = { "cup", "belt0", "belt1", "belt2", "belt3", "belt4", "belt5", "belt6", "belt7", "pet0", "lf0", "pet1", "lf1", "pet2", "lf2", "pet3", "lf3", "pet4", "lf4", "cap", "sprout", "spA", "spB", "glow" },
	groups = {
		cup = { 1, 0, 0 },
		belt0 = { 0.92388, 0, -0.38268 },
		belt1 = { 0.38268, 0, -0.92388 },
		belt2 = { -0.38268, 0, -0.92388 },
		belt3 = { -0.92388, 0, -0.38268 },
		belt4 = { -0.92388, 0, 0.38268 },
		belt5 = { -0.38268, 0, 0.92388 },
		belt6 = { 0.38268, 0, 0.92388 },
		belt7 = { 0.92388, 0, 0.38268 },
		pet0 = { 1, 0, 0 },
		lf0 = { 1, 0, 0 },
		pet1 = { 0.30902, 0, -0.95106 },
		lf1 = { 0.30902, 0, -0.95106 },
		pet2 = { -0.80902, 0, -0.58779 },
		lf2 = { -0.80902, 0, -0.58779 },
		pet3 = { -0.80902, 0, 0.58779 },
		lf3 = { -0.80902, 0, 0.58779 },
		pet4 = { 0.30902, 0, 0.95106 },
		lf4 = { 0.30902, 0, 0.95106 },
		cap = { 1, 0, 0 },
		sprout = { 1, 0, 0 },
		spA = { 0, 0, 1 },
		spB = { 0, 0, 1 },
		glow = { 1, 0, 0 }
	},
	x = { bn0 = { x = 0.3811, y = 0.09096, z = 0.92005 }, bn1 = { x = 0.92005, y = 0.09096, z = 0.3811 }, bn2 = { x = 0.92005, y = 0.09096, z = -0.3811 }, bn3 = { x = 0.3811, y = 0.09096, z = -0.92005 }, bn4 = { x = -0.3811, y = 0.09096, z = -0.92005 }, bn5 = { x = -0.92005, y = 0.09096, z = -0.3811 }, bn6 = { x = -0.92005, y = 0.09096, z = 0.3811 }, bn7 = { x = -0.3811, y = 0.09096, z = 0.92005 } },
	events = {
		{ t = 0.5, type = "stream", untilT = 2.5, color = Color3.fromRGB(233, 255, 154), count = 15, note = "искры вокруг яйца, ~15 в секунду, поднимаются вверх" },
		{ t = 1.55, type = "burst", color = Color3.fromRGB(185, 119, 63), count = 3, group = "belt0", note = "щепки от сегмента пояса" },
		{ t = 1.65, type = "burst", color = Color3.fromRGB(185, 119, 63), count = 3, group = "belt1", note = "щепки от сегмента пояса" },
		{ t = 1.75, type = "burst", color = Color3.fromRGB(185, 119, 63), count = 3, group = "belt2", note = "щепки от сегмента пояса" },
		{ t = 1.85, type = "burst", color = Color3.fromRGB(185, 119, 63), count = 3, group = "belt3", note = "щепки от сегмента пояса" },
		{ t = 1.95, type = "burst", color = Color3.fromRGB(185, 119, 63), count = 3, group = "belt4", note = "щепки от сегмента пояса" },
		{ t = 2.05, type = "burst", color = Color3.fromRGB(185, 119, 63), count = 3, group = "belt5", note = "щепки от сегмента пояса" },
		{ t = 2.15, type = "burst", color = Color3.fromRGB(185, 119, 63), count = 3, group = "belt6", note = "щепки от сегмента пояса" },
		{ t = 2.25, type = "burst", color = Color3.fromRGB(185, 119, 63), count = 3, group = "belt7", note = "щепки от сегмента пояса" },
		{ t = 2.5, type = "flash", color = Color3.fromRGB(244, 255, 176), count = 1, note = "вспышка света изнутри, 0.8 с" },
		{ t = 2.65, type = "ring", color = Color3.fromRGB(201, 255, 138), count = 1, r0 = 0.9, r1 = 3.9, life = 0.9, note = "кольцо по полу" },
		{ t = 2.65, type = "burst", color = Color3.fromRGB(143, 216, 46), color2 = Color3.fromRGB(63, 165, 60), count = 22, note = "листья-кубики вверх и в стороны" },
		{ t = 2.65, type = "burst", color = Color3.fromRGB(241, 255, 176), count = 26, note = "мягкие искры вверх" },
	},
}, self)
end

return EggOpenings
