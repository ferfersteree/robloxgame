--!nonstrict
-- PetAnimations: анимации питомцев SpearHunt, перенесённые из веб-прототипа формула в формулу.
-- Сгенерировано автоматически из кода прототипа. Не править вручную.
--
-- PetAnimations[petId] = { idle, move, react, hatch, rootMotion = { idle, move, react, hatch }, hd, rd, mv, joints }
--   idle(t, set), move(t, set): t — время в секундах
--   react(u, set), hatch(u, set): u — от 0 до 1; длительность реакции rd сек., появления hd сек.
--   set(имяСустава, CFrame) — значение для Motor6D "<имяСустава>_Joint".Transform
--   rootMotion.hatch(u) → CFrame смещения корня, масштаб модели
local PetAnimations = {}

-- ===== общая математика прототипа (совпадает с core.js) =====
local PI, TAU = math.pi, math.pi * 2
local sin, cos, abs, max, min, sqrt = math.sin, math.cos, math.abs, math.max, math.min, math.sqrt
local SCALE = 1.5 -- 1 единица прототипа = 1.5 стада

local function truthy(v) return v ~= nil and v ~= false and v ~= 0 and v ~= "" end
local function orv(a, b) if truthy(a) then return a end return b end
local function iff(c, a, b) if c then return a end return b end
local function forEach(arr, f) for i = 1, #arr do f(arr[i], i - 1) end end
local function map(arr, f) local r = {} for i = 1, #arr do r[i] = f(arr[i], i - 1) end return r end
local function round(x) return math.floor(x + 0.5) end
local function sign(x) if x > 0 then return 1 elseif x < 0 then return -1 end return 0 end
local function hypot(x, y) return sqrt(x * x + y * y) end
local function clamp(x, a, b) a = a or 0 b = b or 1 if x < a then return a elseif x > b then return b end return x end
local function lerp(a, b, t) return a + (b - a) * t end
local function ss(a, b, x) x = clamp((x - a) / (b - a)) return x * x * (3 - 2 * x) end
-- kf(u, u0,v0, u1,v1, ...) — сглаженные ключи
local function kf(u, ...)
	local k = { ... }
	if u <= k[1] then return k[2] end
	for i = 3, #k, 2 do
		if u <= k[i] then
			local d = k[i] - k[i - 2]
			if d == 0 then d = 1e-6 end
			local t = (u - k[i - 2]) / d
			return lerp(k[i - 1], k[i + 1], t * t * (3 - 2 * t))
		end
	end
	return k[#k]
end
local function wave(t, f, ph) return sin(TAU * (t * f + (ph or 0))) end
local function pulse(t, period, dur, off)
	local x = (t + (off or 0)) % period
	if x < dur then return sin(PI * x / dur) end
	return 0
end
local function bump(u, a, b) if u <= a or u >= b then return 0 end return sin(PI * (u - a) / (b - a)) end
local function outBack(t) t = clamp(t) local c = 1.70158 return 1 + (c + 1) * (t - 1) ^ 3 + c * (t - 1) ^ 2 end

-- ===== поза: те же аккумуляторы R/T/S, что в прототипе (оси прототипа, перевод в Roblox — в flush) =====
local VOX = 0.085 -- размер кубика питомца в единицах прототипа

local function newPose(rest)
	local acc = {}
	for name, r in pairs(rest) do acc[name] = { dp = { 0, 0, 0 }, dr = { 0, 0, 0 }, ds = { 1, 1, 1 }, sh = 0 } end
	local A = { w = 1 }
	function A.R(n, x, y, z)
		local a = acc[n] if not a then return A end
		local w = A.w
		a.dr[1] = a.dr[1] + (x or 0) * w a.dr[2] = a.dr[2] + (y or 0) * w a.dr[3] = a.dr[3] + (z or 0) * w
		return A
	end
	function A.T(n, x, y, z)
		local a = acc[n] if not a then return A end
		local w = A.w
		a.dp[1] = a.dp[1] + (x or 0) * w a.dp[2] = a.dp[2] + (y or 0) * w a.dp[3] = a.dp[3] + (z or 0) * w
		return A
	end
	-- МАСШТАБ: Motor6D не умеет масштаб. root → копится в ds и уходит в rootMotion.scale.
	-- Остальные суставы: уменьшение заменено втягиванием к родителю (sh), увеличение игнорируется.
	function A.S(n, x, y, z)
		local a = acc[n] if not a then return A end
		local w = A.w
		if y == nil then y = x end
		if z == nil then z = x end
		a.ds[1] = a.ds[1] * (1 + (x - 1) * w) a.ds[2] = a.ds[2] * (1 + (y - 1) * w) a.ds[3] = a.ds[3] * (1 + (z - 1) * w)
		return A
	end
	function A.chain(pre, n, t, f, ax, ay, az, lag, grow)
		for i = 1, n do
			local ph = -(truthy(lag) and lag or 0.12) * i
			local k = 1 + (grow or 0) * i
			A.R(pre .. i, (ax or 0) * k * wave(t, f, ph), (ay or 0) * k * wave(t, f, ph), (az or 0) * k * wave(t, f, ph))
		end
		return A
	end
	-- МОРГАНИЕ: в прототипе глаз сплющивается (S). Здесь глаз утапливается в голову на 1.4 кубика.
	function A.blink(t, seed)
		seed = seed or 0
		local b = pulse(t, 3.7, 0.16, seed) + pulse(t, 9.1, 0.14, seed + 1.3)
		if b > 0 then
			local k = min(1, b)
			A.T("eyeL", 0, 0, -VOX * 1.4 * k) A.T("eyeR", 0, 0, -VOX * 1.4 * k)
			A.T("browL", 0, -0.012 * b, 0) A.T("browR", 0, -0.012 * b, 0)
		end
		return A
	end
	function A.brows(v, tilt)
		A.T("browL", 0, v, 0) A.T("browR", 0, v, 0)
		if truthy(tilt) then A.R("browL", 0, 0, -tilt) A.R("browR", 0, 0, tilt) end
		return A
	end
	return acc, A
end

-- ===== общие кирпичики движения (lib.js) =====
local L = {}
function L.base(a, t, o)
	o = o or {}
	local f, b, k = orv(o.f, 0.42), orv(o.body, "body"), orv(o.k, 1)
	a.S(b, 1 + 0.012 * k * wave(t, f), 1 + 0.022 * k * wave(t, f, 0.25), 1 + 0.014 * k * wave(t, f))
	a.blink(t, orv(o.seed, 0))
	if o.head ~= 0 then
		local h = orv(o.hn, "head")
		local lk = o.look == nil and 1 or o.look
		a.R(h, 0.035 * wave(t, 0.23, orv(o.seed, 0)), 0.16 * lk * wave(t, 0.097, 0.3 + orv(o.seed, 0)) + 0.07 * lk * wave(t, 0.31), 0.035 * wave(t, 0.17, 0.6))
	end
end
function L.step(a, n, ph, amp, lift, knee)
	local s, c = sin(TAU * ph), cos(TAU * ph)
	a.R(n, -amp * s, 0, 0)
	if truthy(lift) then a.T(n, 0, lift * max(0, c), 0) end
	if truthy(knee) then a.R(n .. "2", knee * max(0, c), 0, 0) end
end
function L.sideStep(a, n, s, ph, amp, lift, knee)
	local sn, c = sin(TAU * ph), cos(TAU * ph)
	a.R(n, 0, -s * amp * sn, s * lift * max(0, c))
	if truthy(knee) then a.R(n .. "2", 0, 0, -s * knee * max(0, c)) end
end
function L.rise(a, u, y, sc) a.T("root", 0, y, 0) a.S("root", sc) end
function L.squash(a, u, a0, a1, amt, j)
	local b = bump(u, a0, a1) * orv(amt, 0.16)
	a.S(orv(j, "root"), 1 + b * 0.7, 1 - b, 1 + b * 0.7)
end
function L.shake(a, u, a0, a1, amt, f)
	if u > a0 and u < a1 then
		local k = (u - a0) / (a1 - a0)
		a.R("root", 0, orv(amt, 0.25) * sin(k * TAU * orv(f, 4)) * (1 - k), 0)
	end
end
function L.flap(a, ang, l, rn) a.R(orv(l, "wingL"), 0, 0, -ang) a.R(orv(rn, "wingR"), 0, 0, ang) end

-- ===== регистрация питомца =====
-- rest[joint] = { px, py, pz, rx, ry, rz } в единицах и осях прототипа (three.js: перед = +Z).
-- Перевод в Roblox (перед = -Z, лево = -X): поворот на 180° вокруг Y, т.е. x → -x, z → -z для сдвигов
-- и углов вокруг X и Z; порядок Эйлера XYZ совпадает с CFrame.fromEulerAnglesXYZ.
local function restCF(r, dp, dr, sc)
	local k = SCALE * sc
	return CFrame.new(-(r[1] + dp[1]) * k, (r[2] + dp[2]) * k, -(r[3] + dp[3]) * k)
		* CFrame.fromEulerAnglesXYZ(-(r[4] + dr[1]), r[5] + dr[2], -(r[6] + dr[3]))
end
local ZERO = { 0, 0, 0 }

local function register(id, info, self)
	local rest, order = info.rest, info.joints
	local acc, A = newPose(rest)
	local entry = { id = id, name = info.name, hd = info.hd, rd = info.rd, mv = info.mv, joints = order, rest = rest, raw = self, acc = acc }
	local function begin()
		for _, a in pairs(acc) do
			a.dp[1], a.dp[2], a.dp[3] = 0, 0, 0 a.dr[1], a.dr[2], a.dr[3] = 0, 0, 0 a.ds[1], a.ds[2], a.ds[3] = 1, 1, 1
		end
	end
	local function add(name, t, w) A.w = w == nil and 1 or w self[name](t, A) end
	-- flush: пишет Transform каждого сустава (кроме root) и возвращает движение корня
	local function flush(set, sc)
		sc = sc or 1
		for i = 1, #order do
			local n = order[i]
			if n ~= "root" then
				local r, a = rest[n], acc[n]
				local dp = a.dp
				local m = (a.ds[1] * a.ds[2] * a.ds[3]) ^ (1 / 3)
				if m < 1 and not entry.noShift then -- S → сдвиг: втягиваем сустав к родителю
					if m < 0 then m = 0 end
					dp = { dp[1] + (m - 1) * r[1], dp[2] + (m - 1) * r[2], dp[3] + (m - 1) * r[3] }
				end
				set(n, restCF(r, ZERO, ZERO, sc):Inverse() * restCF(r, dp, a.dr, sc))
			end
		end
		local a = acc.root
		local rootScale = (a.ds[1] * a.ds[2] * a.ds[3]) ^ (1 / 3)
		local k = SCALE * sc
		return CFrame.new(-a.dp[1] * k, a.dp[2] * k, -a.dp[3] * k) * CFrame.fromEulerAnglesXYZ(-a.dr[1], a.dr[2], -a.dr[3]), rootScale
	end
	entry.begin, entry.add, entry.flush = begin, add, flush
	entry.rootMotion = {}
	local function noop() end
	for _, an in ipairs({ "idle", "move", "react", "hatch" }) do
		-- f(t, set [, scale]): idle/move — t в секундах; react/hatch — u от 0 до 1 (доля от rd / hd)
		entry[an] = function(t, set, sc) begin() add(an, t, 1) flush(set, sc) end
		entry.rootMotion[an] = function(t, sc) begin() add(an, t, 1) return flush(noop, sc) end
	end
	PetAnimations[id] = entry
end


-- ============ moss_bunny — ÐœÐ¾Ñ…Ð¾Ð²Ð¾Ð¹ Ð·Ð°Ð¹Ñ‡Ð¾Ð½Ð¾Ðº ============
do
local self = {}
self.idle = function(t, a)
L.base(a, t, {seed = 0.5})
local g = pulse(t, 2.9, 1.1)
a.T("nose", 0, ((0.014 * wave(t, 7)) * g), 0)
a.S("nose", (1 + ((0.04 * wave(t, 7)) * g)))
a.R("earL", 0, 0, (0.3 * pulse(t, 4.3, 0.32)))
a.R("earR", (0.3 * pulse(t, 5.9, 0.36, 1)), 0, ((-0.12) * pulse(t, 5.9, 0.36, 1)))
a.R("earL", (0.04 * wave(t, 0.4)), 0, 0)
a.R("earR", (0.04 * wave(t, 0.4, 0.3)), 0, 0)
a.R("tail", 0, ((0.35 * pulse(t, 3.3, 0.5, 2)) * wave(t, 6)), 0)
a.R("head", 0, 0, (0.14 * pulse(t, 7.5, 2.2, 3)))
end
self.move = function(t, a)
local p = ((t * 1.55) % 1)
a.blink(t)
a.T("root", 0, kf(p, 0, 0, 0.16, (-0.07), 0.5, 0.62, 0.84, 0, 1, 0), 0)
a.R("body", kf(p, 0, 0.08, 0.16, 0.2, 0.36, (-0.4), 0.66, 0.12, 0.86, 0.26, 1, 0.08), 0, 0)
local sq = kf(p, 0, 0, 0.16, 0.14, 0.3, (-0.12), 0.6, (-0.04), 0.86, 0.16, 1, 0)
a.S("body", (1 + (sq * 0.5)), (1 - sq), (1 + (sq * 0.5)))
local lg = kf(p, 0, 0, 0.16, (-0.3), 0.36, 1.0, 0.62, (-0.5), 0.86, (-0.25), 1, 0)
a.R("legL", lg)
a.R("legR", lg)
a.R("footL", ((-lg) * 0.7))
a.R("footR", ((-lg) * 0.7))
local ar = kf(p, 0, 0, 0.3, 0.55, 0.6, (-0.75), 0.86, (-0.15), 1, 0)
a.R("armL", ar)
a.R("armR", ar)
local er = kf(p, 0, 0, 0.2, (-0.15), 0.42, 0.7, 0.66, 0.35, 0.9, (-0.4), 1, 0)
a.R("earL", er)
a.R("earR", ((er * 0.85) + 0.05))
a.R("head", kf(p, 0, 0, 0.3, 0.28, 0.7, (-0.15), 0.9, 0.18, 1, 0), 0, 0)
a.R("tail", (0.4 * bump(p, 0.2, 0.6)), 0, 0)
end
self.react = function(u, a)
local e = bump(u, 0, 1)
a.T("root", 0, (0.8 * bump(u, 0.1, 0.85)), 0)
a.R("root", 0, (TAU * ss(0.12, 0.82, u)), 0)
a.R("earL", 0, 0, ((0.5 * e) * wave(u, 3)))
a.R("earR", 0, 0, (((-0.5) * e) * wave(u, 3)))
a.R("legL", (0.7 * bump(u, 0.1, 0.5)))
a.R("legR", (0.7 * bump(u, 0.1, 0.5)))
a.R("armL", ((-0.6) * e))
a.R("armR", ((-0.6) * e))
a.brows((0.03 * e))
L.squash(a, u, 0.82, 1, 0.14)
end
self.hatch = function(u, a)
L.rise(a, u, kf(u, 0, 0.22, 0.2, 0.6, 0.36, 0.56, 0.46, 0.42, 0.6, 2.3, 0.8, 0, 1, 0), kf(u, 0, 0.44, 0.44, 0.5, 0.6, 1.03, 0.76, 1, 1, 1))
local pk = bump(u, 0.03, 0.44)
a.R("earL", ((-0.2) * pk), 0, ((0.45 * pk) * wave(u, 7)))
a.R("earR", ((-0.2) * pk), 0, (((-0.45) * pk) * wave(u, 7, 0.3)))
a.R("head", ((-0.2) * pk), ((0.35 * pk) * wave(u, 3.2)), 0)
local j = bump(u, 0.46, 0.8)
a.R("legL", (0.9 * j))
a.R("legR", (0.9 * j))
a.R("footL", ((-0.6) * j))
a.R("footR", ((-0.6) * j))
a.R("armL", ((-0.5) * j))
a.R("armR", ((-0.5) * j))
a.R("root", (((-0.3) * bump(u, 0.46, 0.62)) + (0.22 * bump(u, 0.64, 0.8))), 0, 0)
local fl = kf(u, 0, 0, 0.46, 0, 0.6, 0.6, 0.78, 0.2, 0.84, (-0.7), 0.92, 0.25, 1, 0)
a.R("earL", fl)
a.R("earR", (fl * 0.9))
L.squash(a, u, 0.78, 0.92, 0.24)
a.R("tail", 0, ((0.5 * bump(u, 0.84, 1)) * wave(u, 14)), 0)
end
register("moss_bunny", {
	name = "ÐœÐ¾Ñ…Ð¾Ð²Ð¾Ð¹ Ð·Ð°Ð¹Ñ‡Ð¾Ð½Ð¾Ðº", hd = 2.8, rd = 1.3, mv = { sp = 1.7, rad = 1.3, side = false },
	joints = { "root", "body", "tail", "legL", "footL", "armL", "legR", "footR", "armR", "head", "eyeL", "browL", "eyeR", "browR", "nose", "earL", "earR" },
	rest = {
		root = { 0, 0, 0, 0, 0, 0 },
		body = { 0, 0.6, -0.3, 0, 0, 0 },
		tail = { 0, -0.08, -0.82, 0, 0, 0 },
		legL = { 0.44, -0.16, -0.2, 0, 0, 0 },
		footL = { 0.1, -0.33, 0.3, 0, 0, 0 },
		armL = { 0.24, -0.12, 0.66, 0, 0, 0 },
		legR = { -0.44, -0.16, -0.2, 0, 0, 0 },
		footR = { -0.1, -0.33, 0.3, 0, 0, 0 },
		armR = { -0.24, -0.12, 0.66, 0, 0, 0 },
		head = { 0, 0.5, 0.74, 0, 0, 0 },
		eyeL = { 0.27, 0.05, 0.535, 0, 0.42, 0 },
		browL = { 0.27, 0.29, 0.475, -0.25, 0.42, -0.22 },
		eyeR = { -0.27, 0.05, 0.535, 0, -0.42, 0 },
		browR = { -0.27, 0.29, 0.475, -0.25, -0.42, 0.22 },
		nose = { 0, -0.12, 0.56, 0, 0, 0 },
		earL = { 0.24, 0.4, -0.04, -0.1, 0, -0.22 },
		earR = { -0.24, 0.4, -0.04, -0.1, 0, 0.22 }
	},
}, self)
end

-- ============ storm_falcon — Ð“Ñ€Ð¾Ð·Ð¾Ð²Ð¾Ð¹ ÑÐ¾ÐºÐ¾Ð»Ñ‘Ð½Ð¾Ðº ============
do
local self = {}
self.idle = function(t, a)
L.base(a, t, {seed = 1.2, head = 0})
local k = math.floor((t / 1.5))
local e = ss(0, 0.1, ((t / 1.5) % 1))
local h = function(n)
return (sin((n * 78.233)) * 0.5)
end
a.R("head", (0.08 * h((k + 3))), (0.7 * (h(k) + ((h((k + 1)) - h(k)) * e))), (0.3 * (h((k + 7)) + ((h((k + 8)) - h((k + 7))) * e))))
local ru = pulse(t, 4.6, 0.9)
L.flap(a, (((-0.3) * ru) - ((0.05 * ru) * wave(t, 9))))
a.R("crest", ((0.2 * ru) + (0.04 * wave(t, 0.5))))
a.R("tail", (0.1 * wave(t, 0.4)), 0, ((0.15 * pulse(t, 3.1, 0.5)) * wave(t, 5)))
a.T("root", 0, (0.05 * pulse(t, 3.9, 0.3, 1)), 0)
end
self.move = function(t, a)
local f = 3.6
a.blink(t)
a.T("root", 0, (0.75 + (0.06 * wave(t, f, 0.3))), 0)
a.R("body", (0.75 + (0.05 * wave(t, f, 0.1))))
a.R("head", (-0.7), 0, (0.06 * wave(t, (f / 2))))
L.flap(a, ((-1.3) + (0.85 * wave(t, f))))
a.R("wingL", (0.25 * wave(t, f, 0.25)))
a.R("wingR", (0.25 * wave(t, f, 0.25)))
a.R("legL", 0.9)
a.R("legR", 0.9)
a.R("tail", (0.4 + (0.12 * wave(t, f, 0.4))), (0.1 * wave(t, (f / 2))), 0)
a.R("crest", 0.3)
end
self.react = function(u, a)
local e = bump(u, 0, 1)
L.flap(a, (((-1.5) * e) - ((0.08 * e) * sin((u * 60)))))
a.R("head", ((-0.5) * e), 0, 0)
a.R("nose", (((0.3 * e) * (1 + sin((u * 50)))) * 0.5))
a.R("crest", ((-0.3) * e))
a.T("root", 0, (0.2 * e), 0)
a.R("tail", ((-0.4) * e))
a.brows(((-0.03) * e), (0.3 * e))
end
self.hatch = function(u, a)
L.rise(a, u, kf(u, 0, 0.2, 0.26, 0.36, 0.36, 0.26, 0.52, 1.7, 0.7, 1.5, 0.84, 0, 1, 0), kf(u, 0, 0.42, 0.36, 0.5, 0.5, 1.03, 0.64, 1, 1, 1))
local fl = (ss(0.34, 0.44, u) * (1 - ss(0.8, 0.9, u)))
L.flap(a, ((fl * ((-1.3) + (0.9 * sin((u * 150))))) - (0.4 * bump(u, 0.88, 1))))
a.R("root", ((fl * 0.25) * sin((u * 40))), 0, ((fl * 0.12) * sin((u * 33))))
a.R("body", (0.3 * fl))
a.R("head", (((-0.3) * fl) - (0.3 * bump(u, 0.05, 0.34))), ((0.5 * bump(u, 0.05, 0.34)) * wave(u, 6)), 0)
a.R("legL", ((0.6 * fl) + ((0.3 * fl) * sin((u * 60)))))
a.R("legR", ((0.6 * fl) - ((0.3 * fl) * sin((u * 60)))))
a.R("tail", (0.4 * fl))
L.squash(a, u, 0.82, 0.94, 0.18)
a.R("crest", (0.4 * bump(u, 0.86, 1)))
end
register("storm_falcon", {
	name = "Ð“Ñ€Ð¾Ð·Ð¾Ð²Ð¾Ð¹ ÑÐ¾ÐºÐ¾Ð»Ñ‘Ð½Ð¾Ðº", hd = 3.2, rd = 1.2, mv = { sp = 2, rad = 1.35, side = false },
	joints = { "root", "body", "wingL", "legL", "wingR", "legR", "tail", "head", "eyeL", "browL", "eyeR", "browR", "nose", "crest" },
	rest = {
		root = { 0, 0, 0, 0, 0, 0 },
		body = { 0, 0.66, 0, 0, 0, 0 },
		wingL = { 0.36, 0.14, -0.02, 0, 0, -2.75 },
		legL = { 0.18, -0.42, 0.04, 0, 0, 0 },
		wingR = { -0.36, 0.14, -0.02, 0, 0, 2.75 },
		legR = { -0.18, -0.42, 0.04, 0, 0, 0 },
		tail = { 0, -0.2, -0.38, -0.5, 0, 0 },
		head = { 0, 0.62, 0.08, 0, 0, 0 },
		eyeL = { 0.19, 0.05, 0.31, 0, 0.55, 0 },
		browL = { 0.19, 0.24, 0.29, -0.25, 0.55, 0.4 },
		eyeR = { -0.19, 0.05, 0.31, 0, -0.55, 0 },
		browR = { -0.19, 0.24, 0.29, -0.25, -0.55, -0.4 },
		nose = { 0, -0.06, 0.34, 0, 0, 0 },
		crest = { 0, 0.28, -0.06, 0, 0, 0 }
	},
}, self)
end

-- ============ coral_turtle — ÐšÐ¾Ñ€Ð°Ð»Ð»Ð¾Ð²Ð°Ñ Ñ‡ÐµÑ€ÐµÐ¿Ð°ÑˆÐºÐ° ============
do
local self = {}
self.idle = function(t, a)
L.base(a, t, {seed = 0.6, hn = "neck", look = 0.6})
a.R("neck", ((-0.1) * pulse(t, 5, 2)), 0, 0)
a.R("head", (0.08 * wave(t, 0.2)), 0, (0.1 * pulse(t, 6.4, 2, 1)))
a.S("shell", (1 + (0.012 * wave(t, 0.42))))
a.R("flL", 0, (0.12 * pulse(t, 3.9, 0.7)), (0.12 * pulse(t, 3.9, 0.7)))
a.R("flR", 0, ((-0.1) * pulse(t, 5.1, 0.7, 2)), ((-0.12) * pulse(t, 5.1, 0.7, 2)))
a.R("tail", 0, ((0.4 * pulse(t, 3.3, 0.5)) * wave(t, 4)), 0)
end
self.move = function(t, a)
local f = 0.85
local p = ((t * f) % 1)
a.blink(t)
a.T("root", 0, (0.55 + (0.1 * wave(t, f, 0.2))), 0)
a.R("body", ((-0.12) + (0.1 * wave(t, f, 0.1))), 0, (0.05 * wave(t, (f / 2))))
local st = kf(p, 0, 0, 0.35, 1, 0.55, 0.2, 1, 0)
local sw = kf(p, 0, 0.5, 0.3, (-0.2), 0.6, (-0.5), 1, 0.5)
a.R("flL", 0, sw, ((0.9 * st) - 0.3))
a.R("flR", 0, (-sw), (((-0.9) * st) + 0.3))
a.R("blL", 0, (0.2 * wave(t, (f * 2))), (0.3 * wave(t, (f * 2), 0.25)))
a.R("blR", 0, ((-0.2) * wave(t, (f * 2), 0.5)), ((-0.3) * wave(t, (f * 2), 0.75)))
a.R("neck", (0.25 - (0.1 * wave(t, f, 0.3))), 0, 0)
a.R("head", (-0.15), 0, 0)
a.R("tail", 0, (0.3 * wave(t, (f * 2))), 0)
end
self.react = function(u, a)
local c = (ss(0, 0.18, u) * (1 - ss(0.6, 0.78, u)))
local pop = bump(u, 0.62, 0.98)
a.S("neck", (1 - (0.75 * c)), (1 - (0.9 * c)), (1 - (0.75 * c)))
a.T("neck", 0, ((-0.02) * c), ((-0.3) * c))
forEach({"flL", "flR", "blL", "blR"}, function(n)
return a.S(n, (1 - (0.82 * c)))
end)
a.S("tail", (1 - (0.9 * c)))
a.T("body", 0, ((-0.1) * c), 0)
a.R("body", 0, (((0.5 * c) * sin((u * 30))) * (1 - u)), 0)
a.R("neck", ((-0.3) * pop), 0, 0)
a.brows((0.03 * pop))
a.S("shell", (1 + (0.06 * pop)))
end
self.hatch = function(u, a)
L.rise(a, u, kf(u, 0, 0.1, 0.3, 0.4, 0.48, 0.9, 0.66, 1.25, 0.84, 0, 1, 0), kf(u, 0, 0.42, 0.4, 0.5, 0.56, 1.02, 0.7, 1, 1, 1))
local pd = bump(u, 0.05, 0.84)
local p = ((u * 7) % 1)
local st = kf(p, 0, 0, 0.35, 1, 0.55, 0.2, 1, 0)
a.R("flL", 0, ((0.4 * pd) * wave(u, 7)), (pd * ((0.9 * st) - 0.2)))
a.R("flR", 0, (((-0.4) * pd) * wave(u, 7)), ((-pd) * ((0.9 * st) - 0.2)))
a.R("blL", 0, 0, ((0.4 * pd) * wave(u, 14)))
a.R("blR", 0, 0, (((-0.4) * pd) * wave(u, 14, 0.5)))
a.R("root", (((-0.5) * bump(u, 0.26, 0.6)) + (0.3 * bump(u, 0.6, 0.84))), (TAU * ss(0.4, 0.84, u)), 0)
local nk = (1 - ss(0.02, 0.3, u))
a.S("neck", (1 - (0.7 * nk)), (1 - (0.85 * nk)), (1 - (0.7 * nk)))
a.T("neck", 0, 0, ((-0.28) * nk))
L.squash(a, u, 0.82, 0.94, 0.12)
a.R("neck", ((-0.2) * bump(u, 0.86, 1)), 0, 0)
a.R("tail", 0, ((0.5 * bump(u, 0.86, 1)) * wave(u, 14)), 0)
end
register("coral_turtle", {
	name = "ÐšÐ¾Ñ€Ð°Ð»Ð»Ð¾Ð²Ð°Ñ Ñ‡ÐµÑ€ÐµÐ¿Ð°ÑˆÐºÐ°", hd = 3.2, rd = 1.5, mv = { sp = 1.2, rad = 1.3, side = false },
	joints = { "root", "body", "shell", "co1", "co2", "co3", "neck", "head", "eyeL", "browL", "eyeR", "browR", "flL", "blL", "flR", "blR", "tail" },
	rest = {
		root = { 0, 0, 0, 0, 0, 0 },
		body = { 0, 0.42, -0.05, 0, 0, 0 },
		shell = { 0, 0, 0, 0, 0, 0 },
		co1 = { 0.38, 0.36, 0.1, 0, 0, -0.4 },
		co2 = { 0.14, 0.38, -0.42, -0.4, 0, 0 },
		co3 = { -0.1, 0.42, 0.12, 0, 0, 0.3 },
		neck = { 0, 0.02, 0.72, 0.5, 0, 0 },
		head = { 0, 0.36, 0.04, -0.5, 0, 0 },
		eyeL = { 0.17, 0.08, 0.32, 0, 0.45, 0 },
		browL = { 0.17, 0.28, 0.27, -0.25, 0.45, -0.2 },
		eyeR = { -0.17, 0.08, 0.32, 0, -0.45, 0 },
		browR = { -0.17, 0.28, 0.27, -0.25, -0.45, 0.2 },
		flL = { 0.56, -0.1, 0.42, 0, -1.05, -0.12 },
		blL = { 0.5, -0.1, -0.5, 0, -2.3, -0.1 },
		flR = { -0.56, -0.1, 0.42, 0, 1.05, 0.12 },
		blR = { -0.5, -0.1, -0.5, 0, 2.3, 0.1 },
		tail = { 0, -0.06, -0.84, 0, 0, 0 }
	},
}, self)
end

return PetAnimations
