# SpearHunt — экспорт яиц и питомцев в Roblox (партия 1)

В партии: питомцы `moss_bunny`, `storm_falcon`, `coral_turtle` и яйцо `forest`.
Файлы сгенерированы из кода веб-прототипа. В Roblox Studio они **не открывались** — формат `.rbxmx` и работу модулей в Studio нужно проверить на вашей стороне.

## 1. Модели → ReplicatedStorage.PetModels

1. В Studio создайте папку `ReplicatedStorage.PetModels`.
2. Правый клик по папке → **Insert from File…** → выберите все файлы из `Models/`.
3. В папке появятся модели `moss_bunny`, `storm_falcon`, `coral_turtle`, `egg_forest`.

У каждой модели `PrimaryPart` — заякоренная кость `root` в точке опоры на полу. Ставьте модель через `model:PivotTo(cframe)`.

## 2. Модули → ReplicatedStorage.PetModules

1. Создайте папку `ReplicatedStorage.PetModules`.
2. Создайте в ней четыре `ModuleScript` с именами `PetAnimations`, `EggOpenings`, `PetAnimator`, `EggPlayer`.
3. Вставьте в каждый содержимое одноимённого файла из `Modules/`.

Модули должны лежать в одной папке: `PetAnimator` и `EggPlayer` подключают соседей через `script.Parent`.

## 3. Проиграть открытие яйца и появление питомца

`LocalScript` (например, в `StarterPlayerScripts`):

```lua
local RS = game:GetService("ReplicatedStorage")
local Modules = RS.PetModules
local PetAnimations = require(Modules.PetAnimations)
local PetAnimator = require(Modules.PetAnimator)
local EggPlayer = require(Modules.EggPlayer)

local at = CFrame.new(0, 3, 0)      -- где стоит яйцо (точка на полу)
local petId = "moss_bunny"

local egg = RS.PetModels.egg_forest:Clone()
egg:PivotTo(at)
egg.Parent = workspace

EggPlayer.play(egg, "forest", {
	hd = PetAnimations[petId].hd,   -- длительность появления этого питомца
	onEmerge = function()           -- момент, когда питомец выходит из яйца
		local pet = RS.PetModels[petId]:Clone()
		pet:PivotTo(at)
		pet.Parent = workspace
		local anim = PetAnimator.new(pet, petId)
		anim:Hatch()                -- появление, затем сам перейдёт в покой
		anim:Start()
		-- позже: anim:SetMode("move"), anim:SetMode("idle"), anim:React()
	end,
	onEvent = function(ev) end,     -- частицы: см. EggOpenings.forest.events
	onDone = function() egg:Destroy() end,
})
```

Покой яйца на витрине: `local conn = EggPlayer.idle(egg, "forest")`, остановить — `conn:Disconnect()`.

Напрямую, без `PetAnimator`: `PetAnimations[petId].idle(t, set)`, где `set(joint, cf)` пишет `Motor6D.Transform`. Для `idle` и `move` аргумент — секунды; для `react` и `hatch` — доля от 0 до 1 (длительности `rd` и `hd` в секундах лежат рядом в таблице). `rootMotion.hatch(u)` возвращает смещение корня и масштаб модели.

## Что сделано не один в один

- **Шахматка двух тонов убрана у питомцев.** С ней каждый кубик — отдельная деталь: 1 849–4 548 на питомца при лимите 600. Кубики одного цвета склеены в блоки, ступенчатая форма сохранена. У яйца шахматка осталась: 436 кубиков укладываются в лимит.
- **Мелкие выступы прорежены** там, где не хватило лимита: moss_bunny — 71 из 142; storm_falcon — 59 из 59; coral_turtle — 130 из 130.
- **Масштаб (S) в анимациях питомцев:**
  - корень (`root`) — вынесен в `rootMotion`, `PetAnimator` применяет его через `Model:ScaleTo`;
  - моргание (сплющивание глаз) — глаз утапливается в голову;
  - уменьшение сустава — заменено втягиванием к родителю: `coral_turtle` react и hatch (шея, ласты, хвост прячутся в панцирь);
  - дыхание и пружинящее сжатие — практически не переносятся (увеличение игнорируется, уменьшение на 1–2% даёт едва заметный сдвиг): `moss_bunny` idle (`nose`) и move (`body`), `coral_turtle` idle и react (`shell`), дыхание тела в idle у всех трёх.
- **Масштаб групп яйца** передаётся третьим аргументом `set(name, cf, k)`. `EggPlayer` меняет размер свечения, а многодетальные группы при `k < 1` растворяет прозрачностью вместо сжатия.
- **Частицы** не перенесены как эффекты: в `events` лежат время, тип, цвет и количество. Поток искр в прототипе зависит от частоты кадров, в таблице он записан как примерно 15 в секунду.
- **Не входит:** постановка по редкости (лучи, ореол, замедление, облёт камеры), приземлительные кольца и искры, интерфейс.

## Соглашения

- Оси: перед модели = −Z, верх = +Y, левая сторона = −X. Из three.js это поворот на 180° вокруг Y.
- Единицы: 1 единица прототипа = 1.5 стада.
- Кость сустава — невидимая `Part` с именем сустава; внутри неё `Motor6D` `"<сустав>_Joint"` (Part0 — родительская кость, Part1 — эта) и детали этого сустава, приваренные `Weld`.
- Материалы: `SmoothPlastic`; свечение яйца и блики глаз — `Neon`.

## Проверка перед выдачей

- Формулы Luau прогнаны в Lua 5.5 с заглушками `CFrame`/`Vector3` и сверены с прототипом по всем суставам: 4 анимации × 6–7 моментов времени на питомца, 11 моментов открытия яйца. Расхождение — на уровне погрешности чисел (до 1e-15 у питомцев, 4e-6 у яйца).
- Положение каждой кости через цепочку `C0 * Transform` совпадает с положением сустава в прототипе, переведённым в оси Roblox. Это покрывает знаки поворотов: нога, идущая вперёд в прототипе, идёт к −Z.
- Каждый сустав из анимаций есть в модели под тем же именем; `PetAnimator.new` дополнительно проверяет это при запуске.
- `PetAnimator.lua` и `EggPlayer.lua` написаны вручную и не запускались.

## Таблица

| Модель | Деталей (с костями) | Суставов | Суставы |
|---|---|---|---|
| moss_bunny | 572 | 17 | root, body, tail, legL, footL, armL, legR, footR, armR, head, eyeL, browL, eyeR, browR, nose, earL, earR |
| storm_falcon | 446 | 14 | root, body, wingL, legL, wingR, legR, tail, head, eyeL, browL, eyeR, browR, nose, crest |
| coral_turtle | 590 | 17 | root, body, shell, co1, co2, co3, neck, head, eyeL, browL, eyeR, browR, flL, blL, flR, blR, tail |
| egg_forest | 461 | 25 | root, cup, belt0, belt1, belt2, belt3, belt4, belt5, belt6, belt7, pet0, lf0, pet1, lf1, pet2, lf2, pet3, lf3, pet4, lf4, cap, sprout, spA, spB, glow |
