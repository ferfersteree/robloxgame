# SpearHunt — экспорт яиц и питомцев в Roblox (полный)

25 питомцев и 5 яиц. Файлы сгенерированы из кода веб-прототипа.
В Roblox Studio они **не открывались**: формат `.rbxmx` и работу модулей в Studio нужно проверить на вашей стороне. Начните с одной модели и одного открытия.

## 1. Модели → ReplicatedStorage.PetModels

1. В Studio создайте папку `ReplicatedStorage.PetModels`.
2. Правый клик по папке → **Insert from File…** → выберите все 30 файлов из `Models/`.
3. Питомцы называются по id (`moss_bunny`), яйца — `egg_forest`, `egg_amber`, `egg_tide`, `egg_storm`, `egg_astral`.

`PrimaryPart` каждой модели — заякоренная кость `root` в точке опоры на полу. Ставьте модель через `model:PivotTo(cframe)`.

## 2. Модули → ReplicatedStorage.PetModules

1. Создайте папку `ReplicatedStorage.PetModules`.
2. Создайте в ней четыре `ModuleScript`: `PetAnimations`, `EggOpenings`, `PetAnimator`, `EggPlayer`.
3. Вставьте в каждый содержимое одноимённого файла из `Modules/`.

Модули должны лежать в одной папке: `PetAnimator` и `EggPlayer` подключают соседей через `script.Parent`.

## 3. Проиграть открытие яйца и появление питомца

`LocalScript` (например, в `StarterPlayerScripts`):

```lua
local RS = game:GetService("ReplicatedStorage")
local Modules = RS.PetModules
local PetAnimations = require(Modules.PetAnimations)
local PetAnimator = require(Modules.PetAnimator)
local EggPlayer = require(Modules.EggPlayer)

local at = CFrame.new(0, 3, 0)      -- где стоит яйцо (точка на полу)
local eggId, petId = "forest", "moss_bunny"

local egg = RS.PetModels["egg_" .. eggId]:Clone()
egg:PivotTo(at)
egg.Parent = workspace

EggPlayer.play(egg, eggId, {
	hd = PetAnimations[petId].hd,   -- длительность появления этого питомца
	onEmerge = function()           -- момент, когда питомец выходит из яйца
		local pet = RS.PetModels[petId]:Clone()
		pet:PivotTo(at)
		pet.Parent = workspace
		local anim = PetAnimator.new(pet, petId)
		anim:Hatch()                -- появление, затем сам перейдёт в покой
		anim:Start()
		-- позже: anim:SetMode("move"), anim:SetMode("idle"), anim:React()
	end,
	onEvent = function(ev) end,     -- частицы: см. EggOpenings[eggId].events
	onDone = function() egg:Destroy() end,
})
```

Покой яйца на витрине: `local conn = EggPlayer.idle(egg, eggId)`, остановить — `conn:Disconnect()`.

Напрямую, без `PetAnimator`: `PetAnimations[petId].idle(t, set)`, где `set(joint, cf)` пишет `Motor6D.Transform`. Для `idle` и `move` аргумент — секунды; для `react` и `hatch` — доля от 0 до 1 (длительности `rd` и `hd` в секундах лежат рядом в таблице). `rootMotion.hatch(u)` возвращает смещение корня и масштаб модели.

`EggOpenings[eggId].update(t, set, hd)` возвращает яркость света, непрозрачность свечения и таблицу `{ sway, sun, crack }`: наклон всего яйца (морское), непрозрачность солнечного рисунка (янтарное) и трещины-молнии (грозовое). `EggPlayer` всё это применяет сам.

## Что сделано не один в один

- **Шахматка двух тонов у питомцев убрана.** С ней каждый кубик — отдельная деталь: 1 849–5 371 на питомца при лимите 600. Кубики одного цвета склеены в блоки, ступенчатая форма сохранена. У яиц шахматка осталась.
- **Цветочный ёжик упрощён сильнее остальных:** три ряда листьев-иголок (`sp1`, `sp2`, `sp4`) собраны из кубиков вдвое крупнее, один близкий оттенок слит с соседним. Иначе выходило 869 деталей.
- **Янтарный броненосец:** три близких оттенка слиты с соседними.
- **Мелкие выступы прорежены** там, где не хватило лимита (оставлено/было): clover_beetle 87/173; moss_bunny 71/142; flower_hedgehog 19/145; amber_armadillo 21/142; sun_lion_cub 62/123; honey_griffin 44/88; amber_basilisk 60/119; storm_dragon 58/116; sky_kitsune 10/128; eclipse_dragon 60/119.
- **Кристаллы на яйцах** (грозовое, янтарные включения) — бруски, повёрнутые на 45°, а не восьмигранники: среди Block/Ball/Cylinder/Wedge такой формы нет.
- **Масштаб (S) в анимациях питомцев.** Правила:
  - корень (`root`) — вынесен в `rootMotion`, `PetAnimator` применяет его через `Model:ScaleTo`;
  - моргание (сплющивание глаз) — глаз утапливается в голову; прочие S на `eyeL`/`eyeR` (прищур, зевок) при уменьшении тоже втягивают глаз;
  - уменьшение любого другого сустава — заменено втягиванием к родительскому суставу;
  - увеличение (распушение, вспышка, дыхание) — игнорируется.

  Где S встречается помимо дыхания тела и моргания:

  | Питомец | Анимация: суставы |
  |---|---|
| moss_bunny | idle: nose; move: body |
| hazel_squirrel | react: 't'+i; hatch: 't'+i |
| flower_hedgehog | idle: nose; move: nose; react: 'sp'+i, 'f'+i |
| guardian_fawn | react: lfL, lfR; hatch: lfL, lfR |
| sand_jerboa | idle: nose |
| amber_armadillo | idle: nose, shell; react: shell |
| sun_lion_cub | idle: eyeL, eyeR; react: maneL, maneR, maneT; hatch: maneL, maneR, maneT |
| amber_basilisk | idle: 'cr'+i; react: 'cr'+i; hatch: 'cr'+i |
| bubble_crab | idle: bubA; react: eyeL, eyeR, bubA; hatch: bubA, bubB, bubC |
| coral_turtle | idle: shell; react: neck, n, tail, shell; hatch: neck |
| pearl_axolotl | react: n, eyeL, eyeR; hatch: n |
| tide_ray | idle: pearl |
| little_leviathan | react: earL, earR; hatch: earL, earR, finL, finR |
| spark_salamander | idle: 'sp'+i; move: 'sp'+i; react: 'sp'+i, eyeL, eyeR; hatch: root, 'sp'+i |
| cloud_lamb | idle: 'p'+i; move: 'p'+i; react: 'p'+i, hornL, hornR; hatch: 'p'+i |
| storm_dragon | idle: nose; react: hornL, hornR |
| sky_kitsune | react: p+'3', eyeL, eyeR; hatch: eyeL, eyeR, p+'3' |
| comet_kitten | idle: eyeL, eyeR; react: star; hatch: star, eyeL, eyeR |
| moon_owlet | idle: eyeR, body; react: body, eyeL, eyeR; hatch: body |
| nebula_moth | react: wingL, wingR; hatch: wingL, wingR, hwL, hwR |
| eclipse_dragon | idle: halo, nose; react: halo; hatch: halo, eyeL, eyeR |
| astral_phoenix | idle: aura; react: aura; hatch: eyeL, eyeR, aura |

- **Масштаб групп яйца** передаётся третьим аргументом `set(name, cf, k)`. `EggPlayer` меняет размер светящихся групп, а остальные при `k < 1` растворяет прозрачностью вместо сжатия. Неравномерный масштаб (трещина грозового яйца сужается по двум осям) сведён к одному числу.
- **Частицы и молнии** не перенесены как эффекты: в `events` лежат время, тип (`burst`, `ring`, `flash`, `bolt`, `stream`), цвет, количество и пояснение. Потоки (`stream`) в прототипе случайные и зависят от частоты кадров; в таблице записана примерная частота в секунду.
- **Не входит:** постановка по редкости (лучи, ореол, замедление, облёт камеры), кольца и искры при приземлении питомца, интерфейс.

## Соглашения

- Оси: перед модели = −Z, верх = +Y, левая сторона = −X. Из three.js это поворот на 180° вокруг Y.
- Единицы: 1 единица прототипа = 1.5 стада.
- Кость сустава — невидимая `Part` с именем сустава; внутри неё `Motor6D` `"<сустав>_Joint"` (Part0 — родительская кость, Part1 — эта) и детали этого сустава, приваренные `Weld`.
- Материалы: `SmoothPlastic`; свечение, кристаллы и блики глаз — `Neon`; пузыри крабика — `Glass`.

## Проверка перед выдачей

- Формулы Luau прогнаны в Lua 5.5 с заглушками `CFrame`/`Vector3` и сверены с прототипом по всем суставам: 4 анимации × 6–7 моментов времени на каждого из 25 питомцев, 16 моментов каждого из 5 открытий. Расхождение — до 1e-15 у питомцев и до 2e-9 у яиц.
- Положение каждой кости через цепочку `C0 * Transform` совпадает с положением сустава в прототипе, переведённым в оси Roblox. Это покрывает знаки поворотов: нога, идущая вперёд в прототипе, идёт к −Z.
- Каждый сустав из анимаций есть в модели под тем же именем; `PetAnimator.new` дополнительно проверяет это при запуске.
- Все 30 файлов разбираются как XML, ссылки `Part0`/`Part1` целы, деталей не больше 600, минимальный размер детали 0.05.
- Luau проверялся интерпретатором Lua, а не Luau: синтаксис сгенерированных модулей общий для обоих, но в самой среде Roblox код не запускался.
- `PetAnimator.lua` и `EggPlayer.lua` написаны вручную и не запускались вообще (в них синтаксис Luau: `+=`, `:Connect`).

## Таблица

| Модель | Название | Деталей (с костями) | Суставов | Суставы |
|---|---|---|---|---|
| clover_beetle | ÐšÐ»ÐµÐ²ÐµÑ€Ð½Ñ‹Ð¹ Ð¶ÑƒÑ‡Ð¾Ðº | 534 | 25 | root, body, wingL, wingR, head, eyeL, browL, eyeR, browR, antL1, antL2, antR1, antR2, l1L, l1L2, l2L, l2L2, l3L, l3L2, l1R, l1R2, l2R, l2R2, l3R, l3R2 |
| moss_bunny | ÐœÐ¾Ñ…Ð¾Ð²Ð¾Ð¹ Ð·Ð°Ð¹Ñ‡Ð¾Ð½Ð¾Ðº | 572 | 17 | root, body, tail, legL, footL, armL, legR, footR, armR, head, eyeL, browL, eyeR, browR, nose, earL, earR |
| hazel_squirrel | ÐžÑ€ÐµÑ…Ð¾Ð²Ñ‹Ð¹ Ð±ÐµÐ»ÑŒÑ‡Ð¾Ð½Ð¾Ðº | 593 | 22 | root, body, legL, footL, armL, legR, footR, armR, nut, head, eyeL, browL, eyeR, browR, nose, earL, earR, t1, t2, t3, t4, t5 |
| flower_hedgehog | Ð¦Ð²ÐµÑ‚Ð¾Ñ‡Ð½Ñ‹Ð¹ Ñ‘Ð¶Ð¸Ðº | 600 | 22 | root, body, sp1, sp2, sp3, sp4, sp5, f1, f2, f3, head, eyeL, browL, eyeR, browR, nose, earL, earR, flL, blL, flR, blR |
| guardian_fawn | Ð¥Ñ€Ð°Ð½Ð¸Ñ‚ÐµÐ»ÑŒ-Ð¾Ð»ÐµÐ½Ñ‘Ð½Ð¾Ðº | 500 | 24 | root, body, tail, neck, head, eyeL, browL, eyeR, browR, nose, earL, antL, lfL, earR, antR, lfR, flL, flL2, blL, blL2, flR, flR2, blR, blR2 |
| sand_jerboa | ÐŸÐµÑÑ‡Ð°Ð½Ñ‹Ð¹ Ñ‚ÑƒÑˆÐºÐ°Ð½Ñ‡Ð¸Ðº | 479 | 23 | root, body, legL, shinL, footL, armL, legR, shinR, footR, armR, head, eyeL, browL, eyeR, browR, nose, earL, earR, t1, t2, t3, t4, t5 |
| amber_armadillo | Ð¯Ð½Ñ‚Ð°Ñ€Ð½Ñ‹Ð¹ Ð±Ñ€Ð¾Ð½ÐµÐ½Ð¾ÑÐµÑ† | 600 | 20 | root, body, shell, flL, blL, flR, blR, head, eyeL, browL, eyeR, browR, nose, earL, earR, t1, t2, t3, t4, t5 |
| sun_lion_cub | Ð¡Ð¾Ð»Ð½ÐµÑ‡Ð½Ñ‹Ð¹ Ð»ÑŒÐ²Ñ‘Ð½Ð¾Ðº | 584 | 23 | root, body, armL, legL, footL, armR, legR, footR, head, eyeL, browL, eyeR, browR, nose, earL, earR, maneL, maneR, maneT, t1, t2, t3, tuft |
| honey_griffin | ÐœÐµÐ´Ð¾Ð²Ñ‹Ð¹ Ð³Ñ€Ð¸Ñ„Ð¾Ð½Ñ‡Ð¸Ðº | 561 | 23 | root, body, blL, blL2, flL, flL2, wingL, blR, blR2, flR, flR2, wingR, t1, t2, t3, tuft, head, eyeL, browL, eyeR, browR, nose, crest |
| amber_basilisk | Ð¯Ð½Ñ‚Ð°Ñ€Ð½Ñ‹Ð¹ Ð²Ð°ÑÐ¸Ð»Ð¸ÑÐº | 553 | 27 | root, body, flL, flL2, blL, blL2, flR, flR2, blR, blR2, t1, t2, t3, t4, t5, head, eyeL, browL, eyeR, browR, nose, crest, cr1, cr2, cr3, cr4, cr5 |
| bubble_crab | ÐŸÑƒÐ·Ñ‹Ñ€ÑŒÐºÐ¾Ð²Ñ‹Ð¹ ÐºÑ€Ð°Ð±Ð¸Ðº | 501 | 33 | root, body, bubA, bubB, bubC, stalkL, eyeL, browL, l1L, l1L2, l2L, l2L2, l3L, l3L2, l4L, l4L2, stalkR, eyeR, browR, l1R, l1R2, l2R, l2R2, l3R, l3R2, l4R, l4R2, clawL, clawL2, pinL, clawR, clawR2, pinR |
| coral_turtle | ÐšÐ¾Ñ€Ð°Ð»Ð»Ð¾Ð²Ð°Ñ Ñ‡ÐµÑ€ÐµÐ¿Ð°ÑˆÐºÐ° | 590 | 17 | root, body, shell, co1, co2, co3, neck, head, eyeL, browL, eyeR, browR, flL, blL, flR, blR, tail |
| pearl_axolotl | Ð–ÐµÐ¼Ñ‡ÑƒÐ¶Ð½Ñ‹Ð¹ Ð°ÐºÑÐ¾Ð»Ð¾Ñ‚Ð»ÑŒ | 596 | 27 | root, body, flL, blL, flR, blR, t1, t2, t3, t4, head, eyeL, browL, eyeR, browR, g1L, g1L2, g2L, g2L2, g3L, g3L2, g1R, g1R2, g2R, g2R2, g3R, g3R2 |
| tide_ray | ÐŸÑ€Ð¸Ð»Ð¸Ð²Ð½Ñ‹Ð¹ ÑÐºÐ°Ñ‚Ð¸Ðº | 349 | 19 | root, body, pearl, head, eyeL, browL, eyeR, browR, lobeL, lobeR, wingL, wingL2, wingR, wingR2, t1, t2, t3, t4, tip |
| little_leviathan | ÐœÐ°Ð»ÐµÐ½ÑŒÐºÐ¸Ð¹ Ð»ÐµÐ²Ð¸Ð°Ñ„Ð°Ð½ | 433 | 22 | root, s1, s2, s3, s4, s5, s6, s7, finL, finR, t1, t2, t3, fluke, head, eyeL, browL, eyeR, browR, nose, earL, earR |
| spark_salamander | Ð˜ÑÐºÑ€Ð¾Ð²Ð°Ñ ÑÐ°Ð»Ð°Ð¼Ð°Ð½Ð´Ñ€Ð° | 448 | 25 | root, body, sp1, sp2, sp3, flL, flL2, blL, blL2, flR, flR2, blR, blR2, t1, t2, t3, t4, t5, t6, tip, head, eyeL, browL, eyeR, browR |
| cloud_lamb | ÐžÐ±Ð»Ð°Ñ‡Ð½Ñ‹Ð¹ Ð±Ð°Ñ€Ð°ÑˆÐµÐº | 440 | 30 | root, body, p1, p2, p3, p4, p5, p6, p7, p8, flL, flL2, blL, blL2, flR, flR2, blR, blR2, tail, head, eyeL, browL, eyeR, browR, nose, tuft, earL, hornL, earR, hornR |
| storm_falcon | Ð“Ñ€Ð¾Ð·Ð¾Ð²Ð¾Ð¹ ÑÐ¾ÐºÐ¾Ð»Ñ‘Ð½Ð¾Ðº | 446 | 14 | root, body, wingL, legL, wingR, legR, tail, head, eyeL, browL, eyeR, browR, nose, crest |
| storm_dragon | Ð¨Ñ‚Ð¾Ñ€Ð¼Ð¾Ð²Ð¾Ð¹ Ð´Ñ€Ð°ÐºÐ¾Ð½Ñ‡Ð¸Ðº | 550 | 31 | root, body, flL, flL2, blL, blL2, wingL, wingL2, flR, flR2, blR, blR2, wingR, wingR2, t1, t2, t3, t4, t5, tip, neck, head, eyeL, browL, eyeR, browR, nose, hornL, earL, hornR, earR |
| sky_kitsune | ÐÐµÐ±ÐµÑÐ½Ñ‹Ð¹ ÐºÐ¸Ñ†ÑƒÐ½Ñ | 600 | 33 | root, body, flL, flL2, blL, blL2, flR, flR2, blR, blR2, head, eyeL, browL, eyeR, browR, nose, earL, earR, ka1, ka2, ka3, kb1, kb2, kb3, kc1, kc2, kc3, kd1, kd2, kd3, ke1, ke2, ke3 |
| comet_kitten | ÐšÐ¾Ð¼ÐµÑ‚Ð½Ñ‹Ð¹ ÐºÐ¾Ñ‚Ñ‘Ð½Ð¾Ðº | 453 | 23 | root, body, flL, flL2, blL, blL2, flR, flR2, blR, blR2, head, eyeL, browL, eyeR, browR, nose, earL, earR, t1, t2, t3, t4, star |
| moon_owlet | Ð›ÑƒÐ½Ð½Ñ‹Ð¹ ÑÐ¾Ð²Ñ‘Ð½Ð¾Ðº | 418 | 15 | root, body, wingL, legL, wingR, legR, tail, head, eyeL, browL, eyeR, browR, nose, earL, earR |
| nebula_moth | Ð¢ÑƒÐ¼Ð°Ð½Ð½Ð¾ÑÑ‚Ð½Ñ‹Ð¹ Ð¼Ð¾Ñ‚Ñ‹Ð»Ñ‘Ðº | 440 | 23 | root, body, t1, t2, t3, l1L, l2L, l3L, wingL, hwL, l1R, l2R, l3R, wingR, hwR, head, eyeL, browL, eyeR, browR, nose, antL, antR |
| eclipse_dragon | Ð”Ñ€Ð°ÐºÐ¾Ð½Ñ‡Ð¸Ðº Ð·Ð°Ñ‚Ð¼ÐµÐ½Ð¸Ñ | 542 | 31 | root, body, flL, flL2, blL, blL2, wingL, wingL2, flR, flR2, blR, blR2, wingR, wingR2, t1, t2, t3, t4, t5, tip, neck, head, eyeL, browL, eyeR, browR, nose, hornL, hornR, crest, halo |
| astral_phoenix | ÐÑÑ‚Ñ€Ð°Ð»ÑŒÐ½Ñ‹Ð¹ Ñ„ÐµÐ½Ð¸ÐºÑ | 578 | 35 | root, body, wingL, legL, wingR, legR, pa1, pa2, pa3, pa4, pb1, pb2, pb3, pb4, pc1, pc2, pc3, pc4, pd1, pd2, pd3, pd4, pe1, pe2, pe3, pe4, neck, head, eyeL, browL, eyeR, browR, nose, crest, aura |
| egg_forest | | 461 | 25 | root, cup, belt0, belt1, belt2, belt3, belt4, belt5, belt6, belt7, pet0, lf0, pet1, lf1, pet2, lf2, pet3, lf3, pet4, lf4, cap, sprout, spA, spB, glow |
| egg_amber | | 435 | 17 | root, base, seg0, inc0, seg1, inc1, seg2, inc2, seg3, inc3, seg4, inc4, seg5, inc5, sun, cap, glow |
| egg_tide | | 595 | 15 | root, low, cup0, cup1, cup2, cup3, cup4, cup5, cup6, cup7, r0, r1, r2, r3, glow |
| egg_storm | | 501 | 25 | root, base, lo0, up0, cl0, lo1, up1, cl1, lo2, up2, cl2, lo3, up3, cl3, lo4, up4, cl4, lo5, up5, cl5, chev, top, cryst, crack, glow |
| egg_astral | | 523 | 20 | root, f0, f1, f2, f3, f4, f5, f6, f7, f8, f9, f10, f11, f12, f13, cap, ringA, ringB, core, glow |
